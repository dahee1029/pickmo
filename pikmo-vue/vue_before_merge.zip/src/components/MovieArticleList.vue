<template>
    <div>
      <!-- 게시글이 없을 경우 처리 -->
      <div v-if="articles.length === 0">There are no articles written on this topic.</div>
      <!-- 게시글이 있을 경우 처리 -->
      <div v-else>
        <div v-for="article in articles" :key="article.id">
          <div>{{ article.title }}</div>
          <!-- <div>{{ article.content }}</div> -->
          <div>{{ username }}</div>
          <div>
          </div>
          <RouterLink
            :to="{ name: 'ArticleDetailView', params: { id: article.id } }"
            >게시글 보러가기
          </RouterLink>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  import { RouterLink } from "vue-router";
  import { ref, computed } from "vue";
  import { useRoute,  onBeforeRouteUpdate } from "vue-router";
  import { useCounterStore } from "@/stores/counter";
  import { onMounted } from "vue";
  
  const route = useRoute();
  const movieId = ref(route.params.movieId);
  const counterStore = useCounterStore();
  const articles = ref([]);
  
  const username = computed(() => counterStore.username);

  const getArticles = async () => {
    articles.value = await counterStore.getmovieArticles(movieId.value);
  };
  
  onMounted(() => {
    getArticles();
  });
  
  onBeforeRouteUpdate(async (to, from) => {
    movieId.value = to.params.movieId;
    await getArticles();
  });
  
  </script>
  
  <style scoped></style>