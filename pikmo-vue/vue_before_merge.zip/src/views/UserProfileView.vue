<!-- <template>
  <h2>{{ username }}'s Profile</h2>
</template>

<script setup>
import { useRoute } from 'vue-router';
const route=useRoute()
const username=route.params.username
</script>

<style scoped>

</style> -->
<template>
  <div>
    <h1>프로필 페이지</h1>
    <div v-if="user">
      <p><strong>유저명:</strong> {{ user.username }}</p>
      <p><strong>성별:</strong> {{ user.gender === "f" ? "여성" : "남성" }}</p>
      <p><strong>이메일:</strong> {{ user.email }}</p>
      <p><strong>팔로워 수:</strong> {{ user.followers_count }}</p>
      <p><strong>팔로잉 수:</strong> {{ user.followings_count }}</p>
      <p>
        <strong>좋아하는 장르:</strong>
        <span v-if="user.favorite_genres && user.favorite_genres.length > 0">
          {{ user.favorite_genres.join(", ") }}
        </span>
        <span v-else>선택한 장르 없음</span>
      </p>
      <button @click="updateProfile">프로필 수정</button>
    </div>
    <div v-else>
      <p>로딩 중...</p>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import axios from "axios";
import { useCounterStore } from "@/stores/counter";
import { useRoute, useRouter } from "vue-router";
const user = ref(null);
const counterStore = useCounterStore();
const API_URL = counterStore.API_URL;
const route = useRoute();
const user_pk = route.params.user_pk;
const router = useRouter();

const updateProfile = () => {
  router.push({ name: "UpdateProfileView", params: { user_pk: user_pk } });
};

onMounted(() => {
  if (!counterStore.token) {
    console.error("유효한 인증 토큰이 없습니다.");
    return;
  }
  if (!user_pk) {
    console.error("user_pk가 유효하지 않습니다.");
    return;
  }
  axios({
    method: "get",
    url: `${API_URL}/users/profile/${user_pk}/`,
    headers: {
      Authorization: `Token ${counterStore.token}`,
    },
  })
    .then((response) => {
      user.value = response.data;
      console.log(user.value);
    })
    .catch((error) => {
      console.error("유저 정보를 불러오는 중 오류 발생:", error);
    });
});
</script>

<style scoped></style>
