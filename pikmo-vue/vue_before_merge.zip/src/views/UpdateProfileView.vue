<template>
  <div>
    <h1>프로필 수정 페이지</h1>
    <div v-if="user">
      <form @submit.prevent="submitProfileUpdate">
        <div>
          <label for="username">사용자 이름</label>
          <input type="text" id="username" v-model="user.username" required />
        </div>
        <div>
          <label for="email">이메일</label>
          <input type="email" id="email" v-model="user.email" required />
        </div>
        <div>
          <label for="gender">성별</label>
          <select id="gender" v-model="user.gender" required>
            <option value="m">남성</option>
            <option value="f">여성</option>
          </select>
        </div>
        <!-- 좋아하는 장르 선택 -->
        <div>
          <p>좋아하는 장르 (최대 3개)</p>
          <select v-model="selectedGenres" multiple>
            <option v-for="genre in genres" :key="genre.id" :value="genre.name">
              {{ genre.name }}
            </option>
          </select>
          <p>선택된 장르: {{ selectedGenres }}</p>
          <p v-if="isMaxSelected" style="color: red;">
            최대 3개의 장르만 선택할 수 있습니다.
          </p>
        </div>
        <div>
          <button @click="goUpdatePassword">비밀번호 변경</button>
          <button type="submit">수정 완료</button>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from "vue";
import axios from "axios";
import { useCounterStore } from "@/stores/counter";
import { useRoute, useRouter } from "vue-router";

const user = ref(null); // 사용자 정보
const counterStore = useCounterStore();
const API_URL = counterStore.API_URL;
const route = useRoute();
const user_pk = route.params.user_pk;
const router = useRouter();
const genres = ref([]); // 장르 목록 초기화
const selectedGenres = ref([]); // 선택된 장르
const isMaxSelected = ref(false);

// 비밀번호 변경 페이지로 이동
const goUpdatePassword = () => {
  router.push({ name: "UpdatePasswordView", params: { user_pk } });
};

// 프로필 정보 수정 함수
const submitProfileUpdate = () => {
  // 유효성 검증 (예: 선택된 장르가 1~3개인지 확인)
  if (selectedGenres.value.length === 0 || selectedGenres.value.length > 3) {
    console.error("선호 장르는 1개 이상 3개 이하로 선택해야 합니다.");
    return;
  }

  axios({
    method: "put",
    url: `${API_URL}/users/profile/${user_pk}/`,
    data: {
      username: user.value.username.trim(), // 공백 제거
      email: user.value.email.trim(), // 공백 제거
      gender: user.value.gender,
      favorite_genres: selectedGenres.value, // 선택된 장르 전송
    },
    headers: {
      Authorization: `Token ${counterStore.token}`,
    },
  })
    .then((response) => {
      console.log("프로필이 수정되었습니다:", response.data);
      router.push({ name: "UserProfileView", params: { user_pk } }); // 수정 완료 후 프로필 페이지로 이동
    })
    .catch((error) => {
      // 오류 처리
      if (error.response) {
        console.error("서버 오류:", error.response.data);
      } else {
        console.error("요청 실패:", error.message);
      }
    });
};
// 장르 목록 가져오기
const getGenres = () => {
  axios({
    method: "get",
    url: `${API_URL}/api/v1/movies/genres/`,
    headers: {
      Authorization: `Token ${counterStore.token}`,
    },
  })
    .then((response) => {
      genres.value = response.data;
    })
    .catch((error) => {
      console.error("장르 목록 불러오기 중 오류 발생:", error);
    });
};

// watch로 selectedGenres를 감시
watch(selectedGenres, (newVal, oldVal) => {
  if (newVal.length > 3) {
    selectedGenres.value = oldVal; // 마지막 선택 제거
    isMaxSelected.value = true;
  } else {
    isMaxSelected.value = false;
  }
});

// 프로필 정보 및 장르 목록 불러오기
onMounted(() => {
  axios({
    method: "get",
    url: `${API_URL}/users/profile/${user_pk}/`,
    headers: {
      Authorization: `Token ${counterStore.token}`,
    },
  })
    .then((response) => {
      user.value = response.data;
      selectedGenres.value = response.data.favorite_genres || []; // 초기 선택값 설정
    })
    .catch((error) => {
      console.error("유저 정보를 불러오는 중 오류 발생:", error);
    });

  getGenres(); // 장르 목록 불러오기
});
</script>

<style scoped></style>
