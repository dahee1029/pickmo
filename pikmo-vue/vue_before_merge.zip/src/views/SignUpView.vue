<template>
  <div>
    <h1>Sign Up Page</h1>
    <form @submit.prevent="signUp">
      <label for="username">username : </label>
      <input type="text" id="username" v-model.trim="username" /><br />

      <label for="password1">password : </label>
      <input type="password" id="password1" v-model.trim="password1" /><br />

      <label for="password2">password confirmation : </label>
      <input type="password" id="password2" v-model.trim="password2" />

      <label for="gender">Gender: </label>
      <select id="gender" v-model="gender">
        <option value="f">여성</option>
        <option value="m">남성</option></select
      ><br />

      <input type="submit" value="SignUp" />
    </form>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { useCounterStore } from "@/stores/counter";

const username = ref(null);
const password1 = ref(null);
const password2 = ref(null);
const gender = ref("f"); // 기본값을 여성('f')으로 설정

const store = useCounterStore();

const signUp = function () {
  const payload = {
    username: username.value,
    password1: password1.value,
    password2: password2.value,
    gender: gender.value,
  };
  store.signUp(payload);
};
</script>

<style></style>
