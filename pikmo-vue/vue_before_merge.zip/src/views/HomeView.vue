<template>
<body class="noscroll">
  <main>
    <section class="intro">
      <div class="grid">
        <div class="row">
        </div>
        <div class="row">
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/4XM8DUTQb3lhLemJC51Jx4a2EuA.jpg)"></div>
            </div>
          </div>
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/uahy4sZXrrYNrQBU7FZEWJAXiZm.jpg)"></div>
            </div>
          </div>
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/1y23ODnVjNoA6ErgTqGerLyKv5t.jpg)"></div>
            </div>
          </div>
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/dlJ9L0m7OBMHm9h6Tv0o0sXWmvJ.jpg)"></div>
            </div>
          </div>
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/cvNvWh3vpZHCCmuZ1g75H8iXuxi.jpg)"></div>
            </div>
          </div>
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/8LnjpwfZOSGOZUIE1uX54RXGlfR.jpg)"></div>
            </div>
          </div>
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/cy09IbbXk1gcpD1PqYLQeRVIhE6.jpg)"></div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/qbFwHNeh2g3gy5C8IbUpj6CYOc6.jpg)"></div>
            </div>
          </div>
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/rLAvJ4yTQ9znYh9hOdcimvTBXme.jpg)"></div>
            </div>
          </div>
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/rFvnZYcJzLoC2l6cTFLQRUgYSgL.jpg)"></div>
            </div>
          </div>
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/95bmIvGIa0QW3QW5SfrxnccAjze.jpg)"></div>
            </div>
          </div>
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/wbivSp46LCDeHGUenf6dLxVDyuM.jpg)"></div>
            </div>
          </div>
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/tb9ZtbjJH14hgOr0f2IVUUuDmsr.jpg)"></div>
            </div>
          </div>
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/gf1cTS5rYIgGDMvqjPZaTbD3Ycy.jpg)"></div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/wbivSp46LCDeHGUenf6dLxVDyuM.jpg)"></div>
            </div>
          </div>
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/ndgaAkooNS1Bw1FCmRHOPgcyPAg.jpg)"></div>
            </div>
          </div>
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/e8SJQra4UUrlZI2Teva7FWtASTM.jpg)"></div>
            </div>
          </div>
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/f6Vt2slR6EiJDfUxXcdwIsq3GCE.jpg)"></div>
            </div>
          </div>
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/osKmkWAwIdyr7NxY5NE52t3bntE.jpg)"></div>
            </div>
          </div>
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/eaXRGkOZCUa3GCetxBXgKCQ90EJ.jpg)"></div>
            </div>
          </div>
          <div class="row__item">
            <div class="row__item-inner">
              <div class="row__item-img" style="background-image:url(https://image.tmdb.org/t/p/original/ueB40E0nt4MJTAbzsb5PnmZ4Mg2.jpg)"></div>
            </div>
          </div>
        </div>
        <div class="row">
        </div>
      </div>
      <div class="fullview"></div>
      <!-- <div class="pickmo-description"> 
        <p>영화 추천을 넘어, 당신의 일상에 영감을 더하다. <br> Pikmo는 영화 팬들을 위한 최적의 선택과 진정한 소통의 장을 제공합니다.</p>
      </div> -->
      <div class="enter"><span>PICKMO</span></div>
    </section>
    <section class="content">
      <div class="content__header">
        <h3>Projects</h3>
      </div>
      <div class="content__text">
        <p class="right">To <strong>accomplish </strong>great things, we must not only act, but also <strong>dream</strong>; not only <strong> plan</strong>, but also <strong>believe</strong>. <br>Creating, learning, and setting goals are fundamental pillars for personal and professional growth. Engaging in continuous creation fosters innovation and keeps the mind active, allowing individuals to explore new ideas and express their unique perspectives. Learning, on the other hand, expands our knowledge base and equips us with the skills necessary to navigate an ever-evolving world. </p>
        <p class="highlight">What you get by achieving your goals is not as important as what you become by achieving your goals.</p>
        <p>We are what we repeatedly do. Excellence, then, is not an act, but a habit. It is through learning that we adapt to new challenges and stay relevant in our fields. Setting goals provides direction and motivation, transforming abstract aspirations into achievable milestones. Goals keep us focused, ensuring that our efforts are aligned with our long-term vision. Together, creating, learning, and setting goals form a dynamic cycle of growth that propels us forward, enabling us to reach our fullest potential and make meaningful contributions to the world around us.</p>
        <p>Embracing the practice of always creating, learning, and setting goals is crucial for cultivating a fulfilling and purposeful life. When we create, we turn our thoughts and imaginations into tangible outcomes, whether through art, writing, innovation, or problem-solving. This creative process not only enriches our lives but also inspires others and fosters a sense of accomplishment. Concurrently, continuous learning keeps us curious and open-minded, enabling us to gain new insights and stay abreast of advancements in our areas of interest. Learning drives personal growth and resilience, allowing us to adapt to changes and overcome obstacles. Setting goals, meanwhile, acts as a roadmap, guiding our creative and learning endeavors towards specific achievements. Goals provide clarity and a sense of purpose, helping us prioritize our efforts and measure our progress. By integrating these practices into our daily lives, we build a strong foundation for lifelong growth, success, and satisfaction. </p>
      </div>
    </section>
  </main>
</body>
</template>

<script setup>
    import { onMounted, reactive } from "vue";
    import { useRouter } from 'vue-router';
    import gsap from "gsap";
    import Flip from "gsap/Flip";
    import Lenis from "@studio-freight/lenis";
  
    
    gsap.registerPlugin(Flip);


    const router=useRouter()


    // Activate the smooth scrolling feature.
    onMounted(() => {
        const body = document.body;
    const enterButton = document.querySelector(".enter");
    const grid = document.querySelector(".grid");
    const gridRows = grid.querySelectorAll(".row");

    // Cache window size and update on resize
    let winsize = { width: window.innerWidth, height: window.innerHeight };
    window.addEventListener("resize", () => {
      winsize = { width: window.innerWidth, height: window.innerHeight };
    });

    let mousepos = { x: winsize.width / 2, y: winsize.height / 2 };

    // Configuration for enabling/disabling animations
    const config = {
      translateX: true,
      skewX: false,
      contrast: true,
      scale: false,
      brightness: true
    };

    // Total number of rows
    const numRows = gridRows.length;
    // Calculate the middle row assuming an odd number of rows
    const middleRowIndex = Math.floor(numRows / 2);

    const middleRow = gridRows[middleRowIndex];
    const middleRowItems = middleRow.querySelectorAll(".row__item");
    const numRowItems = middleRowItems.length;
    const middleRowItemIndex = Math.floor(numRowItems / 2); // Index of the middle item in the middle row
    // Select the .row__item-inner element inside the middle .row__item element of the middle row
    // This element will be used for the animation that transitions the image to fullscreen when the button is clicked
    const middleRowItemInner = middleRowItems[middleRowItemIndex].querySelector(
      ".row__item-inner"
    );
    // And the inner image
    const middleRowItemInnerImage = middleRowItemInner.querySelector(
      ".row__item-img"
    );
    // Setting the final size of the middle image for the reveal effect
    middleRowItemInnerImage.classList.add("row__item-img--large");

    // amt represents the interpolation amount for each row's movement.
    // A higher amt value means faster interpolation and less lag behind the mouse movement.
    const baseAmt = 0.1; // The amt for the middle row, which will have the fastest response.
    const minAmt = 0.05; // Minimum amt value to ensure rows have a noticeable movement lag.
    const maxAmt = 0.1; // Maximum amt value to ensure rows have a noticeable movement lag.

    // Initialize rendered styles for each row with dynamically calculated amt values
    let renderedStyles = Array.from({ length: numRows }, (v, index) => {
      const distanceFromMiddle = Math.abs(index - middleRowIndex);
      // Calculate amt dynamically based on the distance from the middle row
      const amt = Math.max(baseAmt - distanceFromMiddle * 0.03, minAmt);
      // Inverted amt for scale: outermost rows are faster
      const scaleAmt = Math.min(baseAmt + distanceFromMiddle * 0.03, maxAmt);
      let style = { amt, scaleAmt };

      if (config.translateX) {
        style.translateX = { previous: 0, current: 0 };
      }
      if (config.skewX) {
        style.skewX = { previous: 0, current: 0 };
      }
      if (config.contrast) {
        style.contrast = { previous: 100, current: 100 };
      }
      if (config.scale) {
        style.scale = { previous: 1, current: 1 };
      }
      if (config.brightness) {
        style.brightness = { previous: 100, current: 100 };
      }

      return style;
    });

    // Tracks if the render loop is running
    let requestId;

    // Function to get the mouse position
    const getMousePos = (ev) => {
      let posx = 0;
      let posy = 0;
      if (!ev) ev = window.event;
      if (ev.pageX || ev.pageY) {
        posx = ev.pageX;
        posy = ev.pageY;
      } else if (ev.clientX || ev.clientY) {
        posx =
          ev.clientX +
          document.body.scrollLeft +
          document.documentElement.scrollLeft;
        posy =
          ev.clientY + document.body.scrollTop + document.documentElement.scrollTop;
      }
      return { x: posx, y: posy };
    };

    // Update mouse position
    const updateMousePosition = (ev) => {
      const pos = getMousePos(ev);
      mousepos.x = pos.x;
      mousepos.y = pos.y;
    };

    // Linear interpolation function
    const lerp = (a, b, n) => (1 - n) * a + n * b;

    // Map mouse position to translation range
    const calculateMappedX = () => {
      return (((mousepos.x / winsize.width) * 2 - 1) * 40 * winsize.width) / 100;
    };

    // Map mouse position to skew range (-3 to 3)
    const calculateMappedSkew = () => {
      return ((mousepos.x / winsize.width) * 2 - 1) * 3;
    };

    // Map mouse position to contrast range (100 at center to 125 at edges)
    const calculateMappedContrast = () => {
      const centerContrast = 100;
      const edgeContrast = 330;
      const t = Math.abs((mousepos.x / winsize.width) * 2 - 1);
      const factor = Math.pow(t, 2); // Quadratic factor for non-linear mapping
      return centerContrast - factor * (centerContrast - edgeContrast);
    };

    // Map mouse position to scale range (1 at center to 0.95 at edges)
    const calculateMappedScale = () => {
      const centerScale = 1;
      const edgeScale = 0.95;
      return (
        centerScale -
        Math.abs((mousepos.x / winsize.width) * 2 - 1) * (centerScale - edgeScale)
      );
    };

    // Map mouse position to brightness range (100 at center to 15 at edges)
    const calculateMappedBrightness = () => {
      const centerBrightness = 100;
      const edgeBrightness = 15;
      const t = Math.abs((mousepos.x / winsize.width) * 2 - 1);
      const factor = Math.pow(t, 2); // Quadratic factor for non-linear mapping
      return centerBrightness - factor * (centerBrightness - edgeBrightness);
    };

    // Function to get the value of a CSS variable
    // const getCSSVariableValue = (element, variableName) => {
    //   return getComputedStyle(element).getPropertyValue(variableName).trim();
    // };

    // Render the current frame
    const render = () => {
      const mappedValues = {
        translateX: calculateMappedX(),
        skewX: calculateMappedSkew(),
        contrast: calculateMappedContrast(),
        scale: calculateMappedScale(),
        brightness: calculateMappedBrightness()
      };

      // Calculate and set the translation for each row
      gridRows.forEach((row, index) => {
        const style = renderedStyles[index];

        // Update current positions and interpolate values
        for (let prop in config) {
          if (config[prop]) {
            style[prop].current = mappedValues[prop];
            const amt = prop === "scale" ? style.scaleAmt : style.amt;
            style[prop].previous = lerp(
              style[prop].previous,
              style[prop].current,
              amt
            );
          }
        }

        // Apply the interpolated values
        let gsapSettings = {};
        if (config.translateX) gsapSettings.x = style.translateX.previous;
        if (config.skewX) gsapSettings.skewX = style.skewX.previous;
        if (config.scale) gsapSettings.scale = style.scale.previous;
        if (config.contrast)
          gsapSettings.filter = `contrast(${style.contrast.previous}%)`;
        if (config.brightness)
          gsapSettings.filter = `${
            gsapSettings.filter ? gsapSettings.filter + " " : ""
          }brightness(${style.brightness.previous}%)`;

        gsap.set(row, gsapSettings);
      });

      // Continue the render loop
      requestId = requestAnimationFrame(render);
    };

    // Start the render loop
    const startRendering = () => {
      if (!requestId) {
        render();
      }
    };

    // Stop the render loop


    const goMovieList= () => {
      router.push('movies');
    };

    // Initialization function
    const init = () => {
      startRendering();

      // Initialize click event for the "Explore" button
      // enterButton.addEventListener("click", enterFullview);
      // Add touchstart event for mobile devices
      enterButton.addEventListener("click", goMovieList);
    };

    // Mouse movement event listener to update mouse position
    window.addEventListener("mousemove", updateMousePosition);
    // Touch move event listener for touch devices
    window.addEventListener("touchmove", (ev) => {
      const touch = ev.touches[0];
      updateMousePosition(touch);
    });

    const initSmoothScrolling = () => {
      // Initialize Lenis for smooth scroll effects. Lerp value controls the smoothness.
      const lenis = new Lenis({ lerp: 0.15 });

      // Ensure GSAP animations are in sync with Lenis' scroll frame updates.
      gsap.ticker.add((time) => {
        lenis.raf(time * 1000); // Convert GSAP's time to milliseconds for Lenis.
      });

      // Turn off GSAP's default lag smoothing to avoid conflicts with Lenis.
      gsap.ticker.lagSmoothing(0);
    };


    initSmoothScrolling();

    init();
    });
    

    // Call the initialization function

</script>

<style scoped>
    @import url("https://fonts.googleapis.com/css2?family=Anton&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap");

    * {
      box-sizing: border-box;
    }

    :root {
      font-size: 12px;
      --color-text: #292828;
      --color-bg: #ddd;
      --color-link: #000;
      --color-link-hover: #000;
      --page-padding: 1rem;
      --angle: -15deg;
      --trans-content: -30vh;
    }

    body {
      margin: 0;
      color: var(--color-text);
      background-color: var(--color-bg);
      font-family: "Poppins", sans-serif;
      text-transform: uppercase;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
    }

    .noscroll {
      height: 100dvh;
      width: 100%;
      overflow: hidden;
      position: fixed;
      top: 0;
    }
/* 
    a {
      text-decoration: none;
      color: var(--color-link);
      outline: none;
      cursor: pointer;
    }

    a:hover {
      text-decoration: underline;
      color: var(--color-link-hover);
      outline: none;
    }

    a:focus {
      outline: none;
      background: lightgrey;
    }

    a:focus:not(:focus-visible) {
      background: transparent;
    }

    a:focus-visible {
      outline: 2px solid red;
      background: transparent;
    } */

    /* .hidden {
      opacity: 0;
      pointer-events: none;
    } */

    .intro {
      width: 100%;
      height: 100vh;
      overflow: hidden;
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      background: #000;
    }

    .intro::after {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: url(https://github.com/misalagp/imgs/blob/main/noise.png?raw=true),
        radial-gradient(circle, #315f316e 0%, transparent 100%);
      background-size: 250px, 100%;
      pointer-events: none;
    }

    .intro--open {
      height: 80vh;
    }

    .grid {
      gap: 1rem;
      flex: none;
      position: relative;
      width: 200vw;
      height: 200vh;
      display: grid;
      grid-template-rows: repeat(5, 1fr);
      grid-template-columns: 100%;
      transform: rotate(var(--angle));
      transform-origin: center center;
    }

    .row {
      display: grid;
      gap: 1rem;
      grid-template-columns: repeat(7, 1fr);
      will-change: transform, filter;
    }

    .row__item {
      position: relative;
    }

    .row__item-inner {
      position: relative;
      width: 100%;
      height: 100%;
      overflow: hidden;
      border-radius: 10px;
    }

    .row__item-img {
      width: 100%;
      height: 100%;
      background-size: cover;
      background-position: 50% 50%;
      position: absolute;
      top: 0;
      left: 0;
    }

    .row__item-img--large {
      width: 100vw;
      height: 100vh;
      top: 50%;
      left: 50%;
      margin: -50vh 0 0 -50vw;
      background-position: 50% 70%;
      will-change: transform, filter;
    }
    .pickmo-description{
      color: rgba(0, 0, 0, 0.8);
      position: absolute;
      text-transform: uppercase;
      padding: 0.8rem 2.5rem;
      font-weight: 350;
      z-index: 100;
      font-family: "Poppins", sans-serif;
      font-size: 1.1rem;
      background: url(https://github.com/misalagp/imgs/blob/main/noise.png?raw=true),
        radial-gradient(circle, transparent 0%, transparent 100%);
      background-size: 250px, 100%;
      margin-bottom: 120px; /* Enter 버튼과의 간격 */
      text-align: center;
      color: white;
    }

    .enter {
      color: rgba(0, 0, 0, 0.8);
      position: absolute;
      text-transform: uppercase;
      padding: 0.8rem 2.5rem;
      font-weight: 600;
      z-index: 100;
      font-family: "Poppins", sans-serif;
      font-size: 1.5rem;
      /* background: url(https://github.com/misalagp/imgs/blob/main/noise.png?raw=true), */
        /* radial-gradient(circle, transparent 0%, transparent 100%); */
      background-size: 250px, 100%;
      transition: all 0.3s;
      cursor: pointer;
    }

    .enter::before {
      content: "";
      position: absolute;
      width: 100%;
      height: 100%;
      top: 0;
      left: 0;
      border: 1px solid rgba(0, 0, 0, 0.8);
      border-radius: 3rem;
      transition: all 0.3s;
      z-index: -1;
    }

    /* .enter:focus::before,
    .enter:hover::before {
      background-color: rgba(0, 0, 0, 0.2);
    } */

    /* .fullview {
      position: absolute;
      width: 100%;
      height: 100%;
      top: 0;
      left: 0;
      pointer-events: none;
    }

    .fullview .row__item-inner {
      border-radius: 0px;
    } */
/* 
    .content {
      padding: var(--page-padding);
      position: relative;
    }

    .content::before {
      content: "";
      position: absolute;
      border-radius: 10px 10px 0 0;
      height: calc(100% + (-1) * var(--trans-content));
      width: 100%;
      top: 0;
      left: 0;
      z-index: 0;
      background: url(https://github.com/misalagp/imgs/blob/main/noise.png?raw=true),
        radial-gradient(at top, #688d68 0%, #ddd 100%);
      background-size: 250px, 100%;
    }

    .content > * {
      position: relative;
    }

    .content__nav {
      display: flex;
      flex-wrap: wrap;
      gap: 1rem;
      justify-content: space-between;
    }

    .content__header h3 {
      font-size: 2rem;
      font-family: "Anton", sans-serif;
      font-style: normal;
      font-weight: 400;
      margin: 6rem 0 10vh;
      line-height: 0.9;
    }

    .content__text {
      display: flex;
      flex-direction: column;
      gap: 10vh;
      padding: 0 5vw;
    }

    .content__text p {
      max-width: 700px;
      font-size: 1.5rem;
      line-height: 1.4;
      margin: 0;
      margin-left: auto;
    }

    .content__text p.highlight {
      max-width: 1000px;
      font-size: 2rem;
      font-family: "Poppins", sans-serif;
      font-weight: 300;
    }

    .content__footer {
      display: flex;
      justify-content: space-between;
      margin-top: 20vh;
      transform: translateY(calc(-1 * var(--trans-content)));
    } */

    @media screen and (min-width: 53em) {
      body {
        --page-padding: 2rem 3rem;
      }
      .content__header h2 {
        font-size: clamp(2rem, 20vh, 16rem);
      }
      .content__text p.highlight {
        font-size: clamp(2rem, 7vh, 4rem);
      }
    }

</style>