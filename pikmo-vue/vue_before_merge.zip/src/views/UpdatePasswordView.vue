<template>
  <div>
    <h1>비밀번호 변경</h1>
    <form @submit.prevent="submitPasswordChange">
      <div>
        <label for="current_password">현재 비밀번호</label>
        <input
          type="password"
          id="current_password"
          v-model="passwords.current"
          required
        />
      </div>
      <div>
        <label for="new_password">새 비밀번호</label>
        <input
          type="password"
          id="new_password"
          v-model="passwords.new"
          required
        />
      </div>
      <div>
        <label for="confirm_password">새 비밀번호 확인</label>
        <input
          type="password"
          id="confirm_password"
          v-model="passwords.confirm"
          required
        />
      </div>
      <div>
        <button type="submit">비밀번호 변경</button>
      </div>
    </form>
  </div>
</template>

<script setup>
import { ref } from "vue";
import axios from "axios";
import { useCounterStore } from "@/stores/counter";
import { useRoute, useRouter } from "vue-router";

const passwords = ref({
  current: "", // 현재 비밀번호
  new: "", // 새 비밀번호
  confirm: "", // 새 비밀번호 확인
});
const counterStore = useCounterStore();
const API_URL = counterStore.API_URL;
const route = useRoute();
const user_pk = route.params.user_pk;
const router = useRouter();

const submitPasswordChange = () => {
  if (passwords.value.new !== passwords.value.confirm) {
    alert("새 비밀번호와 확인 비밀번호가 일치하지 않습니다.");
    return;
  }

  axios({
    method: "put",
    url: `${API_URL}/users/profile/${user_pk}/password/`,
    data: {
      current_password: passwords.value.current,
      new_password: passwords.value.new,
      confirm_password: passwords.value.confirm,
    },
    headers: {
      Authorization: `Token ${counterStore.token}`,
    },
  })
    .then((response) => {
      alert("비밀번호가 성공적으로 변경되었습니다.");
      passwords.value = { current: "", new: "", confirm: "" }; // 폼 초기화
      router.push({ name: "UpdateProfileView", params: { user_pk: user_pk } });
    })
    .catch((error) => {
      console.error("비밀번호 변경 중 오류 발생:", error);
      alert("비밀번호 변경에 실패했습니다.");
    });
};
</script>
